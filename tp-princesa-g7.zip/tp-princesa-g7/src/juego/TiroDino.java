package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class TiroDino {
	private double x;
	private double y;
	double velocidad;
	boolean posicion;
	Image imgTiro;
	Entorno entorno;
	
	
	//GETTERS Y SETTERS
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	// CONTRUCTOR
	public TiroDino(double x, double y, boolean posicion) {
		this.x = x;
		this.y = y;
		this.velocidad = 5;
		this.posicion = posicion;
		imgTiro = Herramientas.cargarImagen("recursos/tiroDino.png");

	}

	public void dibujarse(Entorno entorno) {
		entorno.dibujarImagen(imgTiro, this.x, this.y, 0, 0.7);
	}

	// MOVIMIENTO DE TIRO
	public void moverse() {
		if (posicion == true) {
			x += velocidad;
			this.imgTiro = Herramientas.cargarImagen("recursos/tiroDinoDer.png");
		} else {
			x -= this.velocidad;
			this.imgTiro = Herramientas.cargarImagen("recursos/tiroDino.png");
		}

	}

	// COLISIONES
	public boolean colisionaTirosDinosConPrincesa(Princesa princesa, TiroDino[] tiro, int num) {

		return colision1(tiro[num].getX(), tiro[num].getY(), princesa.getX(), princesa.getY(), 50);

	}

	public boolean colision1(double x1, double y1, double x2, double y2, double dist) {
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) < dist * dist;
	}
	
	// DETECTA EL LIMITE EN PANTALLA PARA QUE EXISTA EL TIRO
	public boolean estaEnLimite() {
		return this.x <= 799 && this.x >= 0;

	}

}
