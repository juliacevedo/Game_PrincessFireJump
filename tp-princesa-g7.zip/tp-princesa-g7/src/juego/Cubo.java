package juego;

import java.awt.Image;
import java.util.List;
import java.util.Random;
import entorno.Entorno;
import entorno.Herramientas;

public class Cubo {
	private double y;
	private double x;
	private int altura;
	private int ancho;
	private boolean estado;
	private boolean esRompible;
	Image imgCubo, imgcubo2, Ladrillo;
	Random random = new Random();
	Image imgCubo3;

	// CONSTRUCTOR.
	
	public Cubo(double x, double y, int altura, int ancho, boolean estado, boolean tipo) {
		this.y = y;
		this.x = x;
		this.altura = altura;
		this.ancho = ancho;
		this.estado = estado;
		this.esRompible = tipo;
		this.estado = true;
	}
	
	// GETTERS Y SETTERS 
	
	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public boolean isRompible() {
		return esRompible;
	}

	public void setRompible(boolean tipo) {
		this.esRompible = tipo;
	}
	
	// DIBUJA SUELO 
	
	public void DibujarSuelo(Entorno e ) {
        imgCubo3 = Herramientas.cargarImagen("recursos/suelo.png");
        e.dibujarImagen(imgCubo3, this.x, this.y, 0, 0.15);
    }
	

	public boolean colision1(double x1, double y1, double x2, double y2, double dist) {
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) < dist * dist;
	}
	

	// MODELADO DE CUBOS 
	
	public void dibujarCubo(Entorno entorno ) {
		if(this.estado ) {
			if(this.esRompible) {
				imgcubo2 = Herramientas.cargarImagen("cuadrado.png");
				entorno.dibujarImagen(imgcubo2, this.x, this.y, 0, 0.1);
			}
			else {
				imgCubo = Herramientas.cargarImagen("cubo fijo.png");
				entorno.dibujarImagen(imgCubo, this.x, this.y, 0, 0.3);
			}
		}
	}
	
	// COLISION CON CUBOS
	
	public boolean colisionaConPrincesa(Princesa princesa) {
			
			if(this.isRompible()) {
				return colision1(this.x, this.y, princesa.getX(), princesa.getY(), 50);
			}
			else {
				return colision1(this.x, this.y, princesa.getX(), princesa.getY(), 30);
			}
		
		
	}
	
	// COLISION DINOS CON CUBOS
	
	public boolean colisionaConDinos(Tiranosaurio[] tiranos,int num) {
		if(this.isRompible()) {
			return colision1(this.x, this.y, tiranos[num].getX(), tiranos[num].getY()+60, 30);
		}
		else {
			return colision1(this.x, this.y, tiranos[num].getX(), tiranos[num].getY()+60, 50);
		}
	}
	

}
