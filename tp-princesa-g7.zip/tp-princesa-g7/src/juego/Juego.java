package juego;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;

public class Juego extends InterfaceJuego {
	private Entorno entorno;
	private Fondo fondo;
	private Princesa princesa;
	private TiroDino Tiro;
	private Fila[] filas;
	private Tiranosaurio[] dinos;
	private TiroDino[] tiro;
	private Musica musica;
	private Cubo[] cubos;
	private int contador=0;
	private Cubo[] cubo;
	Random random = new Random();
	
	
	private Juego() {
		
		
		// CREACION DE OBJETOS (PRINCESA, ENTORNO, FONDO, FILAS, TIRO, DINO, ARREGLOS DE CUBOS DINOS Y TIROS. -----------
		
		this.princesa = new Princesa(400, 550, 50, 50);
		this.entorno = new Entorno(this, "TpPrincesa", 800, 600);
		this.fondo = new Fondo(400, 300, "fondo.png");
		this.filas = new Fila[3];
		int alturaPiso = 450;
		for (int x = 0; x < 3; x++) {
			this.filas[x] = new Fila(new Coordenada(0, alturaPiso), 16);
			
			alturaPiso -= 150;
		}
		
		// CREACION DE ARREGLO DINOS Y ARREGLO DE LOS TIROS DEL DINO. -----------
		
		this.dinos = new Tiranosaurio[6];
		this.tiro = new TiroDino[7];
		
		
		// CREACION DE OBJETO MUSICA Y METODO REPRODUCIR. -----------
		
		musica = new Musica();
		musica.cargarSonido("C:\\Users\\Usuario\\Downloads\\Cortez-Acevedo-Goyosa-Antonioli-g7\\tp\\tp-princesa-g7\\src\\recursos\\musicaDeFondo.wav");
		musica.reproducir();
		
		// CREACION DE ARREGLO CUBOS Y CADA OBJETO CUBO -----------
		
		cubos = new Cubo[31];
		int posicionCuboAnterior = -25;
		for (int cubo = 0; cubo < 31; cubo++) {
			cubos[cubo] =new Cubo ( posicionCuboAnterior+50, 600, 50, 50, false, false);
			posicionCuboAnterior+=25;
		}


		// CREACION DE TIROS -----------
		
		for (int tiros = 0; tiros < tiro.length; tiros++) {

			if (tiros == 0)
				tiro[tiros] = new TiroDino(500, 90, false);
			if (tiros == 1)
				tiro[tiros] = new TiroDino(200, 90, true);
			if (tiros == 2)
				tiro[tiros] = new TiroDino(500, 240, false);
			if (tiros == 3)
				tiro[tiros] = new TiroDino(200, 240, true);
			if (tiros == 4)
				tiro[tiros] = new TiroDino(530, 390, false);
			if (tiros == 5)
				tiro[tiros] = new TiroDino(200, 390, true);
		}
		
		
		// CREACION DE DINOS -----------
		
		for (int dino = 0; dino < dinos.length; dino++) {

			if (dino == 0)
				this.dinos[dino] = new Tiranosaurio(550, 90, 50, 50, false, true);

			if (dino == 1)
				this.dinos[dino] = new Tiranosaurio(180, 90, 50, 50, true, true);

			if (dino == 2)
				this.dinos[dino] = new Tiranosaurio(450, 240, 50, 50, false, true);
			
			if (dino == 3)
				this.dinos[dino] = new Tiranosaurio(200, 240, 50, 50, true, true);
			
			if (dino == 4)
				this.dinos[dino] = new Tiranosaurio(300, 390, 50, 50, false, true);
			
			if (dino == 5)
				this.dinos[dino] = new Tiranosaurio(240, 390, 50, 50, true, true);
			

		}
		
		// INICIAR ENTORNO -----------
		
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y por lo
	 * tanto es el método más importante de esta clase. Aquí se debe actualizar el
	 * estado interno del juego para simular el paso del tiempo (ver el enunciado
	 * del TP para mayor detalle).
	 */
	public void tick() {

		
		// MODELADO DE FONDO CON PUNTAJE Y ENEMIGOS ELIMINADOS -----------
		
		fondo.dibujarse(entorno);
		entorno.cambiarFont("Super Mario 256", 15, Color.GREEN);
		entorno.escribirTexto("Enemigo Eliminados: "+contador/7, 20, 20);
		entorno.escribirTexto("Puntos: "+contador/7*2, 20, 40);
		
		
		// MODELADO DEL SUELO -----------
		
		Fila.dibujarFilas(this.filas, entorno);
		for (int cubo = 0; cubo < cubos.length; cubo++) {
            cubos[cubo].DibujarSuelo(entorno);
				}

		// TIROS DE LOS DINOS, MOVIMIENTO Y MODELADO -----------
		
		if (dinos[0] != null) {
			Tiranosaurio.tiro(dinos, 0, entorno, tiro, 0);
		}
		if (dinos[1] != null) {
			Tiranosaurio.tiro(dinos, 1, entorno, tiro, 1);
		}
		if (dinos[2] != null) {
			Tiranosaurio.tiro(dinos, 2, entorno, tiro, 2);
		}
		if (dinos[3] != null) {
			Tiranosaurio.tiro(dinos, 3, entorno, tiro, 3);
		}
		if (dinos[4] != null) {
			Tiranosaurio.tiro(dinos, 4, entorno, tiro, 4);
		}
		if (dinos[5] != null) {
			Tiranosaurio.tiro(dinos, 5, entorno, tiro, 5);
		}

		// CREACION DE DINOS -----------

		if (dinos[0] != null) {
			Tiranosaurio.mover(dinos, 0, entorno, tiro);
		}
		if (dinos[1] != null) {
			Tiranosaurio.mover(dinos, 1, entorno, tiro);
		}
		if (dinos[2] != null) {
			Tiranosaurio.mover(dinos, 2, entorno, tiro);
		}
		if (dinos[3] != null) {
			Tiranosaurio.mover(dinos, 3, entorno, tiro);
		}
		if (dinos[4] != null) {
			Tiranosaurio.mover(dinos, 4, entorno, tiro);
		}
		if (dinos[5] != null) {
			Tiranosaurio.mover(dinos, 5, entorno, tiro);
		}
		
		
		// MODELADO DE FONDO PERDISTE, DETIENE MUSICA. -----------
		
		if (this.princesa == null) {
			
			fondo.dibujarsePerdiste(entorno); 
			musica.detener();
			
		}	
		
		// COLISION DINO CON PRINCESA -----------
		
		if (princesa!=null) {
			if (dinos[5] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 5)) {
					princesa = null;
				}
			}
			if (dinos[4] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 4)) {
					princesa = null;
				}
			}
			if (dinos[3] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 3)) {
					princesa = null;
				}
			}
			if (dinos[2] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 2)) {
					princesa = null;
				}
			}
			if (dinos[1] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 1)) {
					princesa = null;
				}
			}
			if (dinos[0] != null && this.princesa != null) {
				if (Tiranosaurio.colisionaConPrincesa(princesa, dinos, 0)) {
					princesa = null;
				}
			}

		}
			

		// 	COLISION DE PRINCESA CON CUBOS X ES CADA FILA -----------
		
		if (princesa != null) {
			for (int x = 0; x < filas.length; x++) {
				for (Cubo cubo : filas[x].getCubos()) {
					if (x == 0) {
						if (cubo.isRompible()) {

						} else {
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 50)) {

								this.princesa.getCoordenadas().moverYCantidad(false, 10);
							}
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 45)
									&& cubo.isEstado() == true) {
								princesa.getCoordenadas().setY(451 - 49);

							}

						}

						
					}
					if (x == 1) {
						if (cubo.isRompible()) {
							
						} else {
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 50)) {

								this.princesa.getCoordenadas().moverYCantidad(false, 10);
							}
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 45)) {
								princesa.getCoordenadas().setY(301 - 49);

							}

						}
					}
					if (x == 2) {
						
						if (cubo.isRompible()) {
						} else {
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 45)) {

								this.princesa.getCoordenadas().moverYCantidad(false, 10);
							}
							if (princesa.colisionaConPrincesaCubo(cubo.getX(), cubo.getY(), 45)) {
								princesa.getCoordenadas().setY(155 - 49);

							}
						}

					}
					if (cubo.colisionaConPrincesa(princesa)) {

						if (cubo.isRompible()) {
							cubo.setEstado(false);
						} else {
							this.princesa.getCoordenadas().moverYCantidad(false, 5);
						}
					}

				}
			}
		}
		// CREACION DEL TIRO DE LA PRINCESA Y DESPLAZAMIENTO -----------
		
		if (princesa != null) {

			if (this.princesa.tiro != null && princesa != null) {
				if (this.princesa.tiro.estaEnLimite() && princesa != null) {
					this.princesa.tiro.dibujarse(entorno);
					this.princesa.tiro.moverse();
				} else {

					this.princesa.tiro = null;
				}
			}
			
			
		// COLISION DEL TIRO DE LA PRINCESA CON ENEMIGO -----------
			
			for (Tiranosaurio t : this.dinos) {
				if (t != null) {

					if (princesa.colisionTiroConDino(this.princesa.tiro, t) && t != null) {
						t.setQuieto(false);
						this.princesa.tiro = null;

						for (TiroDino tiro : this.tiro) {
							t=null;
							tiro = null;
							contador++;
						}
					}
				}

			}
		}
		
		// LA PRINCESA LLEGO A LA CIMA, MODELA PANTALLA CON IMAGEN Y DETIENE LA MUSICA -----------
		
		if (princesa != null) {

			princesa.dibujarse(entorno);
			if (this.princesa.getCoordenadas().getY() < 50 && this.princesa.getCoordenadas().getX() > 590) {
				princesa.getCoordenadas().setY(21);

				musica.detener();
				this.fondo.dibujarseGanaste(entorno);
				
			}
		}
		
		// GRAVEDAD PRINCESA -----------
		
		if (princesa != null) {
			double posicionYPiso = 800;
			if (this.princesa.getCoordenadas().getY() < this.princesa.getPiso()) { 
				if (!(this.princesa.getY() > posicionYPiso)) {
					this.princesa.getCoordenadas().moverYCantidad(false, 10);
				}
			}
		}
		
		
		// MOVIMIENTO DE LA PRINCESA (SALTA, CAMINA Y DISPARA) -----------
		
		if (this.entorno.estaPresionada(this.entorno.TECLA_IZQUIERDA) && princesa != null
				&& this.princesa.getCoordenadas().getX() > 15) { // 550 ) {
			this.princesa.moverIzquierda();
		}
		if (this.entorno.estaPresionada(this.entorno.TECLA_DERECHA) && princesa != null
				&& this.princesa.getCoordenadas().getX() < 780) {
			this.princesa.moverDerecha();
		}
		if (this.entorno.estaPresionada('x') && princesa != null) {
			this.princesa.saltar();
		}

		if (this.entorno.estaPresionada('c') && this.princesa.tiro == null) {
			this.princesa.dispara();
		}
		
		// GRAVEDAD DE LOS ENEMIGOS. -----------
		
		if (dinos[0] != null) {
			Tiranosaurio.colisicionDino(dinos, 0, entorno, filas);
		}
		if (dinos[1] != null) {
			Tiranosaurio.colisicionDino(dinos, 1, entorno, filas);
		}
		if (dinos[2] != null) {
			Tiranosaurio.colisicionDino(dinos, 2, entorno, filas);
		}
		if (dinos[3] != null) {

			Tiranosaurio.colisicionDino(dinos, 3, entorno, filas);
		}
		if (dinos[4] != null) {
			Tiranosaurio.colisicionDino(dinos, 4, entorno, filas);
		}
		if (dinos[5] != null) {
			Tiranosaurio.colisicionDino(dinos, 5, entorno, filas);
		}
		
		
		// COLISION TIRO DEL DINO CON LA PRINCESA. -----------
		
		if (princesa != null) {
			for (int i = 0; i < tiro.length; i++) {
				if (tiro[i] != null && princesa != null) {

					if ((tiro[i].getX() - princesa.getCoordenadas().getX())
							* (tiro[i].getX() - princesa.getCoordenadas().getX())
							+ (tiro[i].getY() - princesa.getCoordenadas().getY())
									* (tiro[i].getY() - princesa.getCoordenadas().getY()) < 50 * 50) {
						princesa = null;
					}

				}

			}
		}
		
		// COLISION TIRO DE LA PRINCESA CON TIRO DEL DINO. -----------
		
		if (princesa != null) {
			for (int i = 0; i < tiro.length; i++) {
				if (tiro[i] != null && princesa.tiro != null) {
					if ((tiro[i].getX() - princesa.tiro.getY()) * (tiro[i].getX() - princesa.tiro.getX())
							+ (tiro[i].getY() - princesa.tiro.getY()) * (tiro[i].getY() - princesa.tiro.getY()) < 5
									* 5) {
						princesa.tiro = null;
						tiro[i] = null;
					}
				}
			}
		}

	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}
}
