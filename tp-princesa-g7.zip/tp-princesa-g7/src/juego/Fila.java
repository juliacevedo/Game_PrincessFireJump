package juego;

import java.util.Random;

import entorno.Entorno;

public class Fila {
	private Cubo[] cubos;
	private Coordenada coordenadas;
	
	public Fila(Coordenada posicionInicial, int cantidadCubos){
		
		// INICIALIZA PROPIEDADES
		this.coordenadas = new Coordenada(posicionInicial.getX(), posicionInicial.getY());
		this.cubos = new Cubo[cantidadCubos];
		
		// PREPARANDO VARIABLES AUXILIARES
		boolean esDestructible = false;
		boolean hayDestructible = false;
		Random randomizer = new Random();
		int posicionCuboAnterior = -25;
		
		
		// CREA FILA Y GENERA CUBOS ROMPIBLES DE FORMA RANDOM
		
		for(int x = 0; x < cantidadCubos; x++) {
			if(randomizer.nextInt(100) % 3 == 0) { 
				esDestructible = true;
				hayDestructible = true;
			}
			if(!(hayDestructible) && (x == cantidadCubos - 1)) {
				this.cubos[x] = new Cubo(posicionCuboAnterior+50, this.coordenadas.getY(),50 , 50, false,true); //en el caso que ningun cubo se haya generado como destructible, fuerzo uno al final
			}
			else {
				this.cubos[x] = new Cubo(posicionCuboAnterior+50, this.coordenadas.getY(),50 , 50, false,esDestructible);
			}
			posicionCuboAnterior += 50;
			esDestructible = false;
			
		}
	}
	
	// GETTERS Y SETTERS
	
	public Cubo[] getCubos() {
		return cubos;
	}

	public void setCubos(Cubo[] cubos) {
		this.cubos = cubos;
	}

	public Coordenada getCoordenadas() {
		return coordenadas;
	}

	public void setCoordenadas(Coordenada coordenadas) {
		this.coordenadas = coordenadas;
	}
	
	// DIBUJA FILA DE CUBOS
	
	public void dibujarFila(Entorno entorno) {
		
		for(Cubo cubo : this.getCubos()) {
				if (cubo != null) {
					cubo.dibujarCubo(entorno);
				}
				
			
			
		}
	}
	
	// DIBUJA FILAS 
	
	public static void dibujarFilas(Fila[] filas, Entorno entorno) {
		for(Fila fila : filas) {
			fila.dibujarFila(entorno);
		}
	}
	
	
}
