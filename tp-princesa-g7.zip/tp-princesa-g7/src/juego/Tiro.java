package juego;

import java.awt.Image;
import java.util.List;
import entorno.Entorno;
import entorno.Herramientas;

public class Tiro {
	int x;
	int y;
   	int velocidad;
	boolean posicion;
	Image imgTiro;
	Entorno entorno;
	
	// CONSTRUCTOR del objeto Tiro. 
	
	public Tiro(int x, int y, boolean posicion) {
		this.x = x;
		this.y = y;
		this.imgTiro = Herramientas.cargarImagen("recursos/disparoIzq.png");
		this.velocidad = 10;
		this.posicion = posicion;
	}
	
	// GETTERS Y SETTERS para accedes a variables privadas.
	
	public  int getX() {
		return x;
	}
	
	public  void setX(int x) {
		x = x;
	}
	
	public  int getY() {
		return y;
	}
	
	public  void setY(int y) {
		this.y = y;
	}
	
	// Metodo para dibujar un tiro.
	
	public void dibujarse(Entorno entorno) {
		entorno.dibujarImagen(imgTiro, this.x, this.y, 0, 0.2);
	}
	
	// Metodo que permite desplazar el tiro.

	public void moverse() {
		if (posicion == true) {
			this.x += this.velocidad;
			this.imgTiro = Herramientas.cargarImagen("recursos/disparoDer.png");
		} else {
			this.x -= this.velocidad;
			this.imgTiro = Herramientas.cargarImagen("recursos/disparoIzq.png");
		}

	}
	
	// Metodo que detecta la colision del tiro de la princesa con el tiro del Dino. (Recibe un indice de parametro para un bucle for)
	
	public  boolean colisionaConPrincesaTiro(Princesa princesa, TiroDino[] tiro,int num) {
		if (princesa.tiro == null) {
			return false;
		}
		return colision1(tiro[num].getX(), tiro[num].getY(), princesa.tiro.getX(),princesa.tiro.getY(), 50);

	}
	
	// Metodo auxiliar colision1 utilizado en todas las colisiones.
	
	public static boolean colision1(double x1, double y1, double x2, double y2, double dist) {
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) < dist * dist;
	}
	
	//Metodo que permite detectar si el tiro esta dentro del limite permitido para que se desplace.
	public boolean estaEnLimite() {
		return this.x <= 799 && this.x >= 0;

	}
	
}