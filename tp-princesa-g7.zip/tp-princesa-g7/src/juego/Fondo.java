package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Fondo {
	private Coordenada coordenadas;
	private Image img;
	private double angulo;
	private Image img2;
	private Image img3;

	// CONTRUCTOR
	public Fondo(int posicionX, int posicionY, String imagen) {
		this.coordenadas = new Coordenada(posicionX, posicionY);
		this.angulo = 0;
		this.img = Herramientas.cargarImagen(imagen);
		this.img2 = Herramientas.cargarImagen("recursos/ganaste.jpg");
		this.img3 = Herramientas.cargarImagen("recursos/perdiste.jpg");

	}

	// DIBUJA FONDO
	public void dibujarse(Entorno entorno) {
		entorno.dibujarImagen(img, this.coordenadas.getX(), this.coordenadas.getY(), this.angulo, 1);
	}
	
	//DIBUJA PANTALLA CON IMAGEN DE GANASTE

	public void dibujarseGanaste(Entorno entorno) {

		entorno.dibujarImagen(img2, this.coordenadas.getX(), this.coordenadas.getY(), this.angulo, 1.6);
	}

	//DIBUJA PANTALLA CON IMAGEN DE PERDISTE
	
	public void dibujarsePerdiste(Entorno entorno) {
		entorno.dibujarImagen(img3, this.coordenadas.getX(), this.coordenadas.getY(), this.angulo, 0.97);

	}
}
