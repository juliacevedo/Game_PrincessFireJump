package juego;

public class Coordenada {
	private int x;
	private int y;
	
	
	//CONSTRUCTOR
	
	public Coordenada(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	//GETTERS Y SETTERS
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
	// MUEVE LOS OBJETOS EN EJE X
	public void moverX(boolean sentido) {
		//recibe un booleano para mover el objeto en sentido horizontal, 
		//si es true, mueve a la derecha, si es false mueve a la izquierda 
		if (sentido) {
			this.x ++;
		}
		else{
			this.x --;
		}
	}
	
	// MUEVE LOS OBJETOS EN EJE Y
	public void moverY(boolean sentido) {
		//recibe un booleano para mover el objeto en sentido vertical, 
		//si es true, mueve para arriba, si es false mueve para abajo
		if (sentido) {
			this.y --;
		}
		else{
			this.y ++;
		}
	}
	
	// MUEVE LOS OBJETOS EN EJE X SEGUN CANTIDAD DE PIXELES
	
	public void moverXCantidad(boolean sentido, int cantidad) {
		//recibe un booleano para mover el objeto en sentido horizontal, 
		//si es true, mueve a la derecha, si es false mueve a la izquierda 
		if (sentido) {
			this.x += cantidad;
		}
		else{
			this.x -= cantidad;
		}
	}
	
	// MUEVE LOS OBJETOS EN EJE Y SEGUN CANTIDAD DE PIXELES
	
	public void moverYCantidad(boolean sentido, int cantidad) {
		//recibe un booleano para mover el objeto en sentido vertical, y la cantidad de pixeles que se quiere mover 
		//si es true, mueve para arriba, si es false mueve para abajo
		if (sentido) {
			this.y -= cantidad;
		}
		else{
			this.y += cantidad;
		}
	}
}
